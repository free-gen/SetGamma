using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Globalization;
using System.Drawing;

namespace GammaContrastApp
{
    class Program
    {
        [DllImport("gdi32.dll")]
        public static extern bool SetDeviceGammaRamp(IntPtr hdc, ref RAMP lpRamp);

        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
        public struct RAMP
        {
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            public ushort[] Red;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            public ushort[] Green;
            [MarshalAs(UnmanagedType.ByValArray, SizeConst = 256)]
            public ushort[] Blue;
        }

        private const string GammaFilePath = "value.ini";

        static void Main()
        {
            float gammaValue = LoadGammaSetting();
            SetGamma(gammaValue);
        }

        private static float LoadGammaSetting()
        {
            if (File.Exists(GammaFilePath))
            {
                string gammaValue = File.ReadAllText(GammaFilePath).Trim();

                if (float.TryParse(gammaValue, NumberStyles.Float, CultureInfo.InvariantCulture, out float gamma) && gamma >= 1.0f && gamma <= 3.0f)
                {
                    return gamma;
                }
            }

            return 1.0f;
        }

        private static void SetGamma(float gamma)
        {
            RAMP ramp = new RAMP
            {
                Red = new ushort[256],
                Green = new ushort[256],
                Blue = new ushort[256]
            };

            for (int i = 0; i < 256; i++)
            {
                int val = (int)Math.Min(65535, Math.Max(0, Math.Pow((i + 1) / 256.0, 1.0 / gamma) * 65535 + 0.5));
                ramp.Red[i] = ramp.Green[i] = ramp.Blue[i] = (ushort)val;
            }

            using (Graphics g = Graphics.FromHwnd(IntPtr.Zero))
            {
                IntPtr hdc = g.GetHdc();

                SetDeviceGammaRamp(hdc, ref ramp);

                g.ReleaseHdc(hdc);
            }
        }
    }
}
